"""
Earnings Sentinel — Web Backend
Serves the front-end and exposes POST /api/generate, which runs the same
pipeline used in the Colab version (fetch -> analyze -> audit -> compare ->
build outputs) and returns the dashboard HTML + Excel (base64) in one call.

Required environment variables (set these on your host, never in code):
  GEMINI_API_KEY, ROIC_API_KEY, SEC_USER_AGENT (recommended: "YourProject you@email.com")

Run locally:  uvicorn app:app --reload
"""
import os
import time
import base64
import traceback
from collections import defaultdict, deque

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import pipeline  # the ported Earnings Sentinel pipeline (fetch/analyze/audit/compare/export)

app = FastAPI(title="Earnings Sentinel")

# ---------------------------------------------------------------------------
# Rate limiting: simple in-memory per-IP sliding window. Good enough for a
# demo/portfolio deployment on a single free-tier instance. Not distributed --
# if you ever scale to multiple instances, swap this for Redis-backed limits.
# ---------------------------------------------------------------------------
MAX_REQUESTS_PER_WINDOW = int(os.environ.get("RATE_LIMIT_COUNT", 8))
WINDOW_SECONDS = int(os.environ.get("RATE_LIMIT_WINDOW_SECONDS", 3600))
_request_log = defaultdict(deque)

def _check_rate_limit(ip: str):
    now = time.time()
    log = _request_log[ip]
    while log and now - log[0] > WINDOW_SECONDS:
        log.popleft()
    if len(log) >= MAX_REQUESTS_PER_WINDOW:
        retry_in = int(WINDOW_SECONDS - (now - log[0]))
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit reached ({MAX_REQUESTS_PER_WINDOW}/hour per visitor). Try again in ~{retry_in // 60} min."
        )
    log.append(now)


class GenerateRequest(BaseModel):
    ticker: str


@app.post("/api/generate")
def generate_report(req: GenerateRequest, request: Request):
    client_ip = request.client.host if request.client else "unknown"
    _check_rate_limit(client_ip)

    ticker = (req.ticker or "").strip().upper()
    if not ticker or not ticker.isalnum() or len(ticker) > 8:
        raise HTTPException(status_code=400, detail="Enter a valid ticker (letters/numbers, up to 8 characters).")

    try:
        bundle = pipeline.run_pipeline(ticker)
    except Exception as e:
        return JSONResponse({
            "success": False,
            "message": (f"Pipeline error for {ticker}: {e}. Note: Roic.ai's free tier may only "
                        f"cover AAPL transcripts -- SEC filing data works for any ticker regardless.")
        })

    if not bundle:
        return JSONResponse({"success": False, "message": f"Pipeline did not complete for {ticker}. Check server logs."})

    try:
        excel_file = pipeline.export_polished_excel(ticker)
        dashboard_file = pipeline.export_html_dashboard(ticker)
    except Exception:
        traceback.print_exc()
        return JSONResponse({"success": False, "message": "Report-building error -- check server logs."})

    with open(dashboard_file, "r") as f:
        dashboard_html = f.read()
    with open(excel_file, "rb") as f:
        excel_b64 = base64.b64encode(f.read()).decode("utf-8")

    return JSONResponse({
        "success": True,
        "dashboard_html": dashboard_html,
        "excel_b64": excel_b64,
        "excel_filename": excel_file,
        "alert": pipeline.generate_alert(ticker) or "",
    })


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


# Serve the front end (static/index.html at the root)
app.mount("/", StaticFiles(directory="static", html=True), name="static")
