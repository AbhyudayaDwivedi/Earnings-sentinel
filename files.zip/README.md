# Earnings Sentinel — Web

Live, no-notebook version of Earnings Sentinel. A visitor types a ticker,
the full 4-agent pipeline (Scraper → Analyst → Auditor → Historian) runs on
the server, and they get the dashboard rendered in-page plus an Excel
download — no API keys, no Colab, no signup.

## Local test run

```bash
pip install -r requirements.txt
export GEMINI_API_KEY=your_key
export ROIC_API_KEY=your_key
export SEC_USER_AGENT="EarningsSentinel your_email@example.com"
uvicorn app:app --reload
```
Visit http://localhost:8000

## Deploy to Render (free, no credit card)

1. Push this folder to a **public or private** GitHub repo. `.gitignore` already
   excludes generated files — your keys are never in the repo either way,
   since they're read from environment variables, not code.
2. Go to [render.com](https://render.com) → New → Web Service → connect your repo.
3. Render will detect `render.yaml` automatically (Build: `pip install -r requirements.txt`,
   Start: `uvicorn app:app --host 0.0.0.0 --port $PORT`).
4. In the Render dashboard, add your three secret environment variables
   (`GEMINI_API_KEY`, `ROIC_API_KEY`, `SEC_USER_AGENT`) — they show as blank
   in `render.yaml` on purpose; you enter the real values only in Render's
   dashboard, never in the repo.
5. Deploy. You'll get a live URL like `https://earnings-sentinel.onrender.com`.

That URL is what you post on LinkedIn.

## Things worth knowing

- **Free tier sleeps after 15 min idle** — first visitor after a quiet period
  waits ~30-60s for the server to wake, on top of the ~20-30s the pipeline
  itself takes. Occasional visitors will see a "loading" state a bit longer
  than a warm server; this is normal, not a bug.
- **Rate limiting is on by default** (8 requests/hour per visitor IP,
  adjustable via `RATE_LIMIT_COUNT`/`RATE_LIMIT_WINDOW_SECONDS` in
  `render.yaml`) — this protects your API quota from being drained by one
  visitor or a bot.
- **Roic.ai's free tier may only guarantee AAPL transcripts.** SEC filing
  data works for any US-listed ticker regardless. The pipeline surfaces this
  as a clear message rather than a raw error if it happens.
- **History is stored on local disk**, which is ephemeral on Render's free
  tier (wiped on redeploy/restart) — quarter-over-quarter delta comparisons
  work within a server session but won't persist indefinitely the way your
  Drive-backed Colab version does. Fine for a live demo; if you want durable
  history later, that's a swap to a small hosted database, not a rebuild.
